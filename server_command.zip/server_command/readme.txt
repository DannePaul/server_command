Simple command script made by DannePaul

Uppl�get �r f�ljande

[Changeme] - L�gg till din text h�r

�ndra Changeme till ditt server namn eller vad du vill.
�ndra L�gg till din text h�r till tex Serverns discord: discord.gg

F�r att l�gga till fler rader g� in i command-c.lua
och l�gg till fler: msg("L�gg till din egen text h�r")