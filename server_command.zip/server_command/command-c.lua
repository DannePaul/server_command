RegisterCommand("info", function()
    msg("Lägg till din egen text här")
    msg("Lägg till din egen text här")
    msg("Lägg till din egen text här")
end, false)

function msg(text)
    TriggerEvent("chatMessage","[Changeme]", {255,0,0}, text)
end

--[[ Command script, made by DannePaul ]]